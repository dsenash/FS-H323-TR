# mod_aa_h323_tr — H.323-транк FreeSWITCH ↔ Avaya Communication Manager

[English version](README.md)

Встроенный модуль FreeSWITCH на чистом C (без Python и сторонних библиотек), который подключает FreeSWITCH
например к Avaya Communication Manager (CM) как H.323-транк. Модуль свободный: лицензирования, trial и ограничений нет
(лицензия MIT, см. [LICENSE](LICENSE)). Формат H323 базирован на Avaya, но должен работать и с другими станциями.

## Архитектура

```
 FreeSWITCH + mod_aa_h323_tr                                 Avaya CM
 ┌─────────────────────────────────────┐
 │ служебное соединение к CM           │ ── TCP, H.225 ──▶ trunk[].ip:port (1720)
 │ слушающий порт local.ip:h225_port   │ ◀── TCP, H.225 ── соединения от CM
 └─────────────────────────────────────┘
```

Модуль `mod_aa_h323_tr.so` состоит из слоёв:

| Файл | Назначение |
|------|-----------|
| `fs/mod_aa_h323_tr.c` | обвязка FreeSWITCH: загрузка модуля, endpoint `aa_h323_tr`, API-команда `aa_h323_tr`, чтение XML-конфига |
| `aa_tr_engine.c/h` | движок на pthreads: listener H.225, служебные соединения к транкам, таблица состояния транков |
| `aa_tr_msg.c/h`, `aa_tr_tpl.h` | сборка и разбор сообщений Q.931/H.225.0/H.245 по шаблонам из реальных дампов обмена с CM |
| `aa_tr_config.c/h`, `aa_json.c/h`, `aa_smap.c/h` | разбор JSON-конфигурации |

Шаблоны сообщений (`aa_tr_tpl.h`) генерирует `tools/gen_tr.py` из дампов обмена с CM. Сами дампы в исходники не входят; каталог с ними задаётся переменной `AA_TR_CAPTURES`.

**Listener.** Модуль слушает TCP `local.ip:local.h225_port`. Если порт занят, модуль всё равно загружается:
в журнале пишется предупреждение, `aa_h323_tr status` показывает `NOT LISTENING (...)`, повтор bind — раз в 5 секунд.
Порт 1720 обычно занят параллельным модулем `mod_aa_h323`, поэтому по умолчанию используется 1722.

**Служебное соединение.** К каждому транку из `trunk[]` модуль сам открывает TCP-соединение на `ip:port` CM и
по нему сообщает о готовности: сразу после подключения — Q.931 STATUS с глобальным call reference (cause 31, затем 16),
дальше STATUS cause 16 каждые 7,6 секунды. STATUS от CM (cause 47 — вне обслуживания; 31 и 16 — в обслуживании)
обновляет состояние транка, его показывает `aa_h323_tr status`. При обрыве соединение восстанавливается через 5 секунд.

**Конфигурация** — два файла в каталоге конфигурации FreeSWITCH:

- `autoload_configs/aa_h323_tr.conf.xml` — путь к JSON (`config-json`), диалплан и контекст для входящих вызовов, необязательный `local-rtp-ip`;
- `aa_h323_tr/aa_h323_tr.json` — основная конфигурация (пример: `config/aa_h323_tr.example.json`):

| Ключ | Значение |
|------|----------|
| `local.ip` | IP **этого** сервера FreeSWITCH (на нём модуль слушает и от его имени сообщает адрес CM) |
| `local.h225_port` | порт приёма H.225; необязателен, по умолчанию 1722 |
| `identity.product`, `identity.version`, `identity.display` | как модуль представляется CM; в примере `FS-AA-H323-TR` / `0.0.N`, где N — номер сборки, подставляется при каждой сборке (`aa_h323_tr status` показывает `build 0.0.N`) |
| `trunk[].name` | имя транка |
| `trunk[].ip`, `trunk[].port` | адрес CM и порт (по умолчанию 1720) |
| `trunk[].codec` | `PCMA` (G.711A) или `PCMU` (G.711μ) |
| `trunk[].lines` | число линий (по умолчанию 100, 0 — без ограничения) |
| `trunk[].in_number_rules[]` | правила для номера ВХОДЯЩЕГО В FreeSWITCH вызова (АТС → FreeSWITCH) `{match, strip, add}`, срабатывает первое подходящее |
| `trunk[].out_number_rules[]` | правила для номера ИСХОДЯЩЕГО ИЗ FreeSWITCH вызова (FreeSWITCH → АТС), тот же формат `{match, strip, add}` |

## Требования

- FreeSWITCH с заголовками для сборки модулей (`freeswitch-dev` либо установка из исходников);
- `gcc`, `make`, `pkg-config`, `awk`; для установки — root.

## Развёртывание через install.sh

```
cd mod_aa_h323_tr
sudo ./install.sh
```

Скрипт выполняет семь шагов: сборка `fs/mod_aa_h323_tr.so`; установка модуля; установка XML-конфига и диалплана
(только если файлов ещё нет); создание/правка `aa_h323_tr.json`; добавление `mod_aa_h323_tr` в `modules.conf.xml`;
проверка подключения диалплана; перезагрузка модуля в работающем FreeSWITCH и вывод `aa_h323_tr status`.

Скрипт спрашивает IP этого сервера (`local.ip`) и порт приёма (`local.h225_port`), предлагая текущие значения.
Без вопросов:

```
sudo AA_TR_LOCAL_IP=192.168.0.6 AA_TR_PORT=1722 ./install.sh
```

Повторный запуск безопасен: значения `local.ip` и `local.h225_port` перезаписываются, остальной JSON (транки, правила номеров) не меняется.

После установки впишите реальные транки в `aa_h323_tr.json` (`trunk[]`: `ip`, `port`, `codec`, `lines`, правила номеров) и перезагрузите модуль:
`fs_cli -x "reload mod_aa_h323_tr"`.

## Развёртывание через deb-пакет

Пакет `mod-aa-h323-tr` собирается на машине, где установлен FreeSWITCH с заголовками (модуль компилируется под него):

```
cd mod_aa_h323_tr
packaging/deb/build-on-target.sh
sudo apt install ./mod-aa-h323-tr_1.0.0_amd64.deb
```

Переменные `build-on-target.sh` (все необязательные): `FS_SRC` — каталог исходников FreeSWITCH, `FS_CFLAGS`/`FS_LIBS` — флаги вручную,
`VER`, `ARCH`, `NOBUILD=1` — упаковать уже собранный `fs/mod_aa_h323_tr.so`. Готовый `.so` можно упаковать и напрямую:
`packaging/deb/build.sh fs/mod_aa_h323_tr.so`.

При установке `postinst` вызывает `/usr/sbin/mod-aa-h323-tr-setup`:

- находит FreeSWITCH (`FS_PREFIX`, либо `FS_MODDIR` и `FS_CONFDIR`, либо автоопределение; значения можно записать в `/etc/default/mod-aa-h323-tr`);
- копирует модуль в каталог модулей;
- создаёт `aa_h323_tr.conf.xml`, диалплан и `aa_h323_tr.json` **только если их нет** (существующие файлы администратора не перезаписываются);
  в новом JSON выставляет `local.ip` по маршруту по умолчанию (можно задать `AA_TR_LOCAL_IP` и `AA_TR_PORT`);
- добавляет `mod_aa_h323_tr` в `modules.conf.xml`.

Если FreeSWITCH не найден, пакет всё равно устанавливается; настройку можно выполнить позже:
`sudo FS_PREFIX=/usr/local/freeswitch mod-aa-h323-tr-setup`.

Удаление: `apt remove mod-aa-h323-tr` выгружает и удаляет модуль, но сохраняет конфигурацию администратора; `apt purge` удаляет и её.
После установки и удаления перезапустите FreeSWITCH или выполните `fs_cli -x "load mod_aa_h323_tr"`.

## Маршрутизация исходящих вызовов FreeSWITCH → АТС

Для FreeSWITCH H.323-транк — это внешнее направление: вызов уходит оператором `bridge` с dial string

```
aa_h323_tr/<транк>/<номер>
```

- `<транк>` — поле `name` транка в `aa_h323_tr.json` (в примере `cm1`);
- `<номер>` — то, что АТС получит как called party number; преобразование номера выполняет диалплан FreeSWITCH;
- calling number и имя берутся из канала (`caller_id_number`, `caller_id_name`; можно задать через `effective_caller_id_*`);
- неизвестный транк даёт отбой `NO_ROUTE_DESTINATION`; причина отбоя АТС возвращается в FreeSWITCH как hangup cause.

Порядок настройки:

1. Убедитесь, что `fs_cli -x "aa_h323_tr status"` показывает транк `in service`.
2. Добавьте extension в свой диалплан (обычно `/etc/freeswitch/dialplan/default/`, контекст `default`). Готовые примеры
   лежат в `config/freeswitch-outbound.example.xml` и установлены в `aa_h323_tr/dialplan-outbound.example.xml` каталога конфигурации FreeSWITCH (файл неактивен, пока вы не скопируете из него extension).
3. `fs_cli -x "reloadxml"`.

Минимальный пример — префикс выхода `9`, номер после него передаётся на АТС без изменений:

```xml
<extension name="to_pbx_cm1">
  <condition field="destination_number" expression="^9(\d{3,15})$">
    <action application="set" data="hangup_after_bridge=true"/>
    <action application="bridge" data="aa_h323_tr/cm1/$1"/>
  </condition>
</extension>
```

Вызов 9111234 с внутреннего телефона уйдёт на АТС как 111234. В файле-примере есть ещё варианты: преобразование внутренних
`0xxx` (в `111xxx` их превращает `out_number_rules`) и последовательный перебор двух транков (`bridge aa_h323_tr/cm1/$1|aa_h323_tr/cm2/$1`).
Проверен исходящий вызов через один транк; остальные варианты — шаблоны, проверьте их на своей АТС.

### Правила номеров: входящие и исходящие — это разные правила

| | `in_number_rules` | `out_number_rules` |
|---|---|---|
| Направление | АТС → FreeSWITCH (вызов ВХОДИТ в FreeSWITCH) | FreeSWITCH → АТС (вызов ВЫХОДИТ из FreeSWITCH) |
| К какому номеру | called number, который прислала АТС | номер из `bridge aa_h323_tr/<транк>/<номер>` |
| Когда | до диалплана FreeSWITCH (контекст `aa_h323_tr`) | после диалплана, перед отправкой на АТС |
| Пример | `{"match":"111","strip":3,"add":"0"}`: АТС набрала 111123 → в диалплан придёт 0123 | `{"match":"0","strip":1,"add":"111"}`: `bridge aa_h323_tr/cm1/0123` → АТС получит 111123 |

Правила каждого набора проверяются по порядку, срабатывает первое подходящее: `match` — с каких цифр начинается номер (пусто — любой),
`strip` — сколько цифр убрать в начале, `add` — что дописать вместо них. Нет подходящего правила — номер не меняется.
Входящие правила на исходящие вызовы не действуют, и наоборот. Calling number правилами не меняется — это делает диалплан.
Преобразовывать номер можно либо в диалплане, либо в `out_number_rules`; не делайте и то и другое для одного номера.
Проверка: `fs_cli -x "aa_h323_tr number cm1 0123 out"` и `fs_cli -x "aa_h323_tr number cm1 111123 in"`.

Входящие от АТС описаны в `aa_h323_tr.json` и `dialplan/aa_h323_tr.xml` (контекст `aa_h323_tr`).

## Настройка CM

В сигнальной группе CM, привязанной к транку:

- `Far-end Node Name` — узел с IP сервера FreeSWITCH;
- `Far-end Listen Port` — `local.h225_port` (1722 по умолчанию).

## Обслуживание

- Состояние: `fs_cli -x "aa_h323_tr status"` — сборка, путь к конфигу, listener (`NOT LISTENING`, если порт занят),
  по каждому транку: адрес, кодек, линии, `in service` или `OUT OF SERVICE`.
- Смена конфигурации: правка `aa_h323_tr.json`, затем `fs_cli -x "reload mod_aa_h323_tr"`.
- Обновление: заново `sudo ./install.sh` либо установка нового deb-пакета. Если после `unload`/`load` новая сборка не подхватилась —
  `systemctl restart freeswitch`.
- Журнал: модуль пишет в журнал FreeSWITCH (`/var/log/freeswitch/freeswitch.log`); искать по `aa_tr` / `aa_h323_tr`. Блок `logging` в JSON читается, но пока не используется.
- Порт 1720 занят: на нём обычно работает `mod_aa_h323`; задайте другой `local.h225_port` (по умолчанию 1722) и тот же порт укажите в CM.
- Тесты разработчика: `make test` (модульные тесты на векторах из дампов), `make asan`, `make tsan`, `make fs-syntax` (проверка синтаксиса обвязки FreeSWITCH по собственным заглушкам).

## Лицензия

MIT, см. [LICENSE](LICENSE). Copyright (c) 2026 Сенашенко Дмитрий. Разработано в Российской Федерации.
